# now-github-starter

This is a simple project that makes a [static deployment](https://zeit.co/docs/deployment-types/static)
to Now.

If you added the [Now app](https://github.com/apps/now), upon
making a pull request, your changes will be automatically deployed.
